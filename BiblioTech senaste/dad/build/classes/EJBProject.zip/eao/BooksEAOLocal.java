package eao;

import java.util.List;

import javax.ejb.Local;

import entites.Book;

@Local
public interface BooksEAOLocal {

	public Book create(Book books);
	public Book update(Book books);
	public void remove(String isbn);

	public Book getBookById(String isbn);
	public List<Book> getAllBooks();
}
